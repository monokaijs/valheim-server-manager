# 2.2.0

- Added size- and SHA-256-verified embedded packages for server-specific companions.
- Kept HTTPS Thunderstore downloads restricted to trusted Thunderstore hosts.

# 2.1.0

- Added schema v2 config targets for server-only, client-only, and shared configuration files.
- Server-only configs are removed from the peer relay manifest.
- Added separate server and client revisions so server-only changes do not interrupt connected clients.
- Kept schema v1 manifests readable for backward compatibility.

# 2.0.0

- Replaced the hardcoded website and server ID with a generic HTTPS `ManifestUrl` configured only on dedicated servers.
- Added an early per-peer RPC handshake that relays the server's validated manifest to bootstrap clients.
- Uses plain JSON manifests with no signing keys or secrets.
- Clients require no configuration and stage changed mod sets safely for the next launch.
- Added an in-game restart prompt and disconnects clients before they join with an incompatible loaded mod set.
- Supports switching between independently managed servers by remembering the last relayed manifest identity.

# 1.1.0

- Polls the manifest every 60 seconds while running as a dedicated server.
- Installs new, updated, and removed managed mods without SSH access.
- Saves and quits after plugin changes so a process supervisor can restart Valheim with the new assemblies.
- Applies config-only updates live and allows an optional restart for mods that do not watch their config files.
- Uses manifest ETags to avoid downloading unchanged payloads.

# 1.0.0

- Initial live manifest synchronization.
- Transitive Thunderstore dependency installation.
- Centrally managed configuration files applied before plugin initialization.
- Isolated managed plugin directory and last-known-good failure behavior.
